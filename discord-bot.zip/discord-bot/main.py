import os
import asyncio
import discord
from discord.ext import commands
import config
import database
from utils import webserver

class UltimateBot(commands.Bot):
    def __init__(self):
        # Set up necessary bot intents
        intents = discord.Intents.default()
        intents.members = True          # Requires "Server Members Intent" enabled in Discord Dev Portal
        intents.message_content = True  # Requires "Message Content Intent" enabled in Discord Dev Portal
        
        super().__init__(command_prefix="!", intents=intents)

    async def setup_hook(self):
        # 1. Initialize Database
        await database.init_db()
        
        # 2. Automatically Load Cogs from the cogs directory
        for filename in os.listdir('./cogs'):
            if filename.endswith('.py'):
                try:
                    await self.load_extension(f'cogs.{filename[:-3]}')
                    print(f"Successfully loaded cog: cogs.{filename[:-3]}")
                except Exception as e:
                    print(f"Failed to load cog cogs.{filename[:-3]}: {e}")
        
        # 3. Sync Slash Commands with Discord
        await self.tree.sync()
        print("Slash commands synced successfully.")

        # 4. Set up Persistent Views
        try:
            from cogs.drops import DropView
            from cogs.generator import GeneratorView
            self.add_view(DropView(self))
            self.add_view(GeneratorView(self))
            print("Persistent views registered.")
        except Exception as e:
            print(f"Notice: Persistent views skipped or not found: {e}")
        
        # 5. Start the Web Server so Render remains happy and active
        self.loop.create_task(webserver.start_server())

    async def on_ready(self):
        print(f'Logged in successfully as {self.user} (ID: {self.user.id})')
        print('--------------------------------------------------')

async def main():
    bot = UltimateBot()
    async with bot:
        # Securely fetch the bot token from Render's environment settings
        token = os.environ.get("DISCORD_TOKEN")
        
        if not token:
            print("CRITICAL ERROR: 'DISCORD_TOKEN' environment variable is completely missing from the host environment!")
        else:
            await bot.start(token)

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        # Handle a clean and graceful manual shutdown
        print("Bot process interrupted manually. Shutting down cleanly.")